=== AL Custom Permalinks ===
Tags: permalink, url, link, address, custom, redirect
Requires at least: 2.6
Tested up to: 4.4.2
Stable tag: 0.7.21

Allow you to set custom permalinks on a per-post, per-tag or per-category basis.

== Description ==

Allow you to set custom permalink on  per-post, per-tag or per-category basis.

== Installation ==

1. Download plugin zip file to your computer and extract in a folder
1. Upload `al-custom-permalink` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==


== Changelog ==
